Please include the following information with your bug report:

Is this a new bug with the latest release, have you seen this earlier?

Which device / browser version was used to reproduce the bug?

Does this happen every time you launch Nightscout, or sometimes?

Steps how to reproduce (if you can’t reproduce the issue, please don’t report the issue / if we can't reproduce the bug, we can't fix)

Please include 1 or more screenshots of the issue appearing, ideally with an annotation on what's wrong
